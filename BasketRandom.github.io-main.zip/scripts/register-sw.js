"use strict";
window.C3_RegisterSW = async function() {
    if (navigator.serviceWorker && 1== 0)
        try {
            const a = await navigator.serviceWorker.register("sw.js", {
                scope: "./"
            });
            console.info("Registered service worker on " + a.scope)
        } catch (a) {
            console.warn("Failed to register service worker: ", a)
        }
}
;
